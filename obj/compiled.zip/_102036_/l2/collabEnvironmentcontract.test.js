/// <mls fileReference="_102036_/l2/collabEnvironmentcontract.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
