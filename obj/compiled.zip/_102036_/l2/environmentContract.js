/// <mls fileReference="_102036_/l2/environmentContract.ts" enhancement="_blank"/>
/**
 * DEFAULTS (fallback seguro)
 */
const defaultNotifications = {
    getFCMTokenForBackend: () => Promise.resolve(null),
    sendRequestMissed: () => Promise.resolve(),
    sendACK: () => Promise.resolve(),
};
const defaultBots = {
    getArgsToBots: () => Promise.resolve({}),
    getBotContextVarsBeforeMessageSend: () => Promise.resolve([]),
    getBotContextVarsBeforeMessageSend2: () => Promise.resolve([]),
};
const defaultAgents = {
    generateSvgAvatar: () => Promise.resolve(null),
    executeAgent: () => Promise.resolve(),
    loadAgent: () => Promise.resolve(null),
};
const defaultTasks = {
    openTaskDetails: () => Promise.resolve({ openLocal: false, element: undefined }),
};
const defaultConfig = {
    getMenuMode: () => 'default',
    generateSvgAvatarEnabled: () => false
};
/**
 * ENV GLOBAL
 */
let _envCollabMessages = null;
export function setEnvironment(env) {
    _envCollabMessages = env;
}
function getEnv() {
    return _envCollabMessages ?? {};
}
/**
 * NORMALIZADORES (garantem tipagem forte)
 */
function getEnvNotifications() {
    return {
        ...defaultNotifications,
        ...getEnv().notifications,
    };
}
function getEnvBots() {
    return {
        ...defaultBots,
        ...getEnv().bots,
    };
}
function getEnvAgents() {
    return {
        ...defaultAgents,
        ...getEnv().agents,
    };
}
function getEnvTasks() {
    return {
        ...defaultTasks,
        ...getEnv().tasks,
    };
}
function getEnvConfig() {
    return {
        ...defaultConfig,
        ...getEnv().config,
    };
}
/**
 * FACADE FINAL (API SEGURA)
 */
export const environment = {
    getAgents: () => getEnv().getAgents?.() ?? Promise.resolve([]),
    getIntegrationsOpenClaw: () => getEnv().getIntegrationsOpenClaw?.() ?? Promise.resolve([]),
    setIntegrationsOpenClaw: (integrations) => getEnv().setIntegrationsOpenClaw?.(integrations) ?? Promise.resolve(),
    notifications: {
        getFCMTokenForBackend: () => getEnvNotifications().getFCMTokenForBackend(),
        sendRequestMissed: () => getEnvNotifications().sendRequestMissed(),
        sendACK: (id) => getEnvNotifications().sendACK(id),
    },
    bots: {
        getArgsToBots: () => getEnvBots().getArgsToBots(),
        getBotContextVarsBeforeMessageSend: (thread, messageText) => getEnvBots().getBotContextVarsBeforeMessageSend(thread, messageText),
        getBotContextVarsBeforeMessageSend2: (vars, myArgs) => getEnvBots().getBotContextVarsBeforeMessageSend2(vars, myArgs),
    },
    agents: {
        generateSvgAvatar: (threadId, userId, promptToAvatar) => getEnvAgents().generateSvgAvatar(threadId, userId, promptToAvatar),
        executeAgent: (agentToCall, context) => getEnvAgents().executeAgent(agentToCall, context),
        loadAgent: (agentName) => getEnvAgents().loadAgent(agentName),
    },
    tasks: {
        openTaskDetails: (messageId, taskId, task, message) => getEnvTasks().openTaskDetails(messageId, taskId, task, message)
    },
    config: {
        getMenuMode: () => getEnvConfig().getMenuMode(),
        generateSvgAvatarEnabled: () => getEnvConfig().generateSvgAvatarEnabled()
    }
};
