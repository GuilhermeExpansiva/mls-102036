/// <mls fileReference="_102036_/l2/shared/interfaces.ts" enhancement="_blank"/>
export var HttpStatus;
(function (HttpStatus) {
    HttpStatus[HttpStatus["OK"] = 200] = "OK";
    HttpStatus[HttpStatus["NOT_MODIFIED"] = 304] = "NOT_MODIFIED";
    HttpStatus[HttpStatus["BAD_REQUEST"] = 400] = "BAD_REQUEST";
    HttpStatus[HttpStatus["UNAUTHORIZED"] = 401] = "UNAUTHORIZED";
    HttpStatus[HttpStatus["NOT_FOUND"] = 404] = "NOT_FOUND";
    HttpStatus[HttpStatus["FORBIDDEN"] = 403] = "FORBIDDEN";
    HttpStatus[HttpStatus["CONFLICT"] = 409] = "CONFLICT";
    HttpStatus[HttpStatus["SERVER_ERROR"] = 500] = "SERVER_ERROR";
    HttpStatus[HttpStatus["NOT_IMPLEMENTED"] = 501] = "NOT_IMPLEMENTED";
})(HttpStatus || (HttpStatus = {}));
export var ThreadFeature;
(function (ThreadFeature) {
    ThreadFeature["Summary"] = "summary";
    ThreadFeature["CustomPlugin"] = "custom_plugin";
    ThreadFeature["Tasks"] = "tasks";
    ThreadFeature["Workflow"] = "workflow";
    ThreadFeature["Notifications"] = "notifications";
    ThreadFeature["Voting"] = "voting";
    ThreadFeature["Moderation"] = "moderation";
    ThreadFeature["Feedback"] = "feedback";
})(ThreadFeature || (ThreadFeature = {}));
export var BotTriggerType;
(function (BotTriggerType) {
    BotTriggerType["OnNewMessage"] = "onNewMessage";
    BotTriggerType["OnMention"] = "onMention";
    BotTriggerType["OnTaskCompleted"] = "onTaskCompleted";
    BotTriggerType["Schedule"] = "schedule";
    BotTriggerType["Manual"] = "manual";
})(BotTriggerType || (BotTriggerType = {}));
